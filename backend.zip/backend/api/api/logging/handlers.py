def log_requests():
    pass

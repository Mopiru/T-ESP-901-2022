from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenRefreshView

from . import views

router = DefaultRouter()
# router.register('profile', ProfileViewSet, basename='Profile')

urlpatterns = [
    path('auth/signin', views.CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('auth/token/refresh', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/signup', views.SignupView.as_view(), name='signup'),
    path('auth/signout', views.SignoutView.as_view(), name='signout'),
    path('profile', views.ProfileView.as_view(), name='profile'),
    path('', include(router.urls)),
]
